package com.roniokta.submissionapp.watches;

public class Watches {
    private String nameWatch;
    private String infoWatch;
    private String watchBadge;
    private String shopWatch;
    private String photoWatch;

    public String getNameWatch() {
        return nameWatch;
    }

    public void setNameWatch(String nameWatch) {
        this.nameWatch = nameWatch;
    }

    public String getInfoWatch() {
        return infoWatch;
    }

    public void setInfoWatch(String infoWatch) {
        this.infoWatch = infoWatch;
    }

    public String getWatchBadge() {
        return watchBadge;
    }

    public void setWatchBadge(String watchBadge) {
        this.watchBadge = watchBadge;
    }

    public String getShopWatch() {
        return shopWatch;
    }

    public void setShopWatch(String shopWatch) {
        this.shopWatch = shopWatch;
    }

    public String getPhotoWatch() {
        return photoWatch;
    }

    public void setPhotoWatch(String photoWatch) {
        this.photoWatch = photoWatch;
    }
}
