package com.roniokta.submissionapp.glasses;

public class Glasses {
    private String nameGlasses;
    private String infoGlasses;
    private String glassesBadge;
    private String shopGlasses;
    private String photoGlasses;

    public String getNameGlasses() {
        return nameGlasses;
    }

    public void setNameGlasses(String nameGlasses) {
        this.nameGlasses = nameGlasses;
    }

    public String getInfoGlasses() {
        return infoGlasses;
    }

    public void setInfoGlasses(String infoGlasses) {
        this.infoGlasses = infoGlasses;
    }

    public String getGlassesBadge() {
        return glassesBadge;
    }

    public void setGlassesBadge(String glassesBadge) {
        this.glassesBadge = glassesBadge;
    }

    public String getShopGlasses() {
        return shopGlasses;
    }

    public void setShopGlasses(String shopGlasses) {
        this.shopGlasses = shopGlasses;
    }

    public String getPhotoGlasses() {
        return photoGlasses;
    }

    public void setPhotoGlasses(String photoGlasses) {
        this.photoGlasses = photoGlasses;
    }
}
