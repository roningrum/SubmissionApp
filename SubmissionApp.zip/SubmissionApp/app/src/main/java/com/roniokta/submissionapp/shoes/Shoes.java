package com.roniokta.submissionapp.shoes;

public class Shoes {
    private String nameShoes;
    private String infoShoes;
    private String shoesBadge;
    private String shopShoes;
    private String photoShoes;

    public String getNameShoes() {
        return nameShoes;
    }

    public void setNameShoes(String nameShoes) {
        this.nameShoes = nameShoes;
    }

    public String getInfoShoes() {
        return infoShoes;
    }

    public void setInfoShoes(String infoShoes) {
        this.infoShoes = infoShoes;
    }

    public String getShoesBadge() {
        return shoesBadge;
    }

    public void setShoesBadge(String shoesBadge) {
        this.shoesBadge = shoesBadge;
    }

    public String getShopShoes() {
        return shopShoes;
    }

    public void setShopShoes(String shopShoes) {
        this.shopShoes = shopShoes;
    }

    public String getPhotoShoes() {
        return photoShoes;
    }

    public void setPhotoShoes(String photoShoes) {
        this.photoShoes = photoShoes;
    }
}
