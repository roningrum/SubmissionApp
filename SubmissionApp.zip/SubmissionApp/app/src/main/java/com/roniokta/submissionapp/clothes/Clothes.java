package com.roniokta.submissionapp.clothes;

public class Clothes {
    private String nameClothes;
    private String infoClothes;
    private String ClothesBadge;
    private String shopClothes;
    private String photoClothes;

    public String getNameClothes() {
        return nameClothes;
    }

    public void setNameClothes(String nameClothes) {
        this.nameClothes = nameClothes;
    }

    public String getInfoClothes() {
        return infoClothes;
    }

    public void setInfoClothes(String infoClothes) {
        this.infoClothes = infoClothes;
    }

    public String getClothesBadge() {
        return ClothesBadge;
    }

    public void setClothesBadge(String clothesBadge) {
        ClothesBadge = clothesBadge;
    }

    public String getShopClothes() {
        return shopClothes;
    }

    public void setShopClothes(String shopClothes) {
        this.shopClothes = shopClothes;
    }

    public String getPhotoClothes() {
        return photoClothes;
    }

    public void setPhotoClothes(String photoClothes) {
        this.photoClothes = photoClothes;
    }
}
